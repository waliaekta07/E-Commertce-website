const NoPage = () => {
    return (
        <div>
            No Page
        </div>
    );
}

export default NoPage;
